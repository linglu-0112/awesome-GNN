# GCN-based_soft_sensor
paper: Development of GCN-based soft sensor for quality prediction of process industry
This is the code of the paper Development of GCN-based soft sensor for quality prediction of process industry. 
The training process of Pensim is implemented in main.py, and readers can add test files by themselves.
The dataset contains Pensim and IndPensim data excel.
The data sources of Pensim and IndPensim are as follows：
[1]	G. Birol, C. Undey, and A. Cinar, “A modular simulation package for fed-batch fermentation: penicillin production,” Comput. Chem. Eng., vol. 11, pp. 1553−1565, 2002.
[2]	S. Goldrick, A. Stefan, D. Lovett, G. Montague, and B. Lennox, “The development of an industrial-scale fed-batch fermentation simulation,” J. Biotechnol., vol. 193, no. 1, pp. 70–82, Jan. 2015.
